-- FICTIONAL DECEASED RECORDS - SIMPLE GRAVEYARD SYSTEM
-- Target: Apache Derby 10.16.1.1; existing APP.PLOTS and APP.BURIALS tables.
-- All names, dates and plot assignments below are fictional demonstration data.
-- These are the SAME 200 plots and 120 burial entries produced by run.bat demo.
--
-- BEFORE RUNNING
-- 1. In the extracted Graveyard-System project folder, run: run.bat init
--    This creates the database AND tables if they do not exist.
-- 2. Close the application. Connect your Derby SQL editor to THAT database:
--    jdbc:derby:C:/YOUR_PROJECT_FOLDER/Graveyard-System/data/cemetery
--    Replace the example folder with the real full path on your computer.
--    Use the embedded Derby driver; this is not a localhost:1527 connection.
-- 3. Execute this entire file in the connected SQL editor.
--    With auto-commit enabled, each INSERT is committed by the SQL client.
--    If auto-commit is off, commit through your client only after success.
-- 4. Disconnect the SQL editor before reopening the application.
--
-- Existing plots are preserved. Existing burials are not updated/deleted.
-- Burials are inserted only into plots that have no burial record.
-- On an EMPTY initialized database: 200 plots, 120 occupied, 80 available.
-- On a populated database: existing occupied plots are skipped; counts may differ.
-- Re-running this file without other changes adds no duplicate rows.
-- Do not run this script simultaneously from multiple SQL editor connections.
-- The database generates RECORD_ID automatically, so it is omitted below.
-- This script does NOT create/drop tables or change the database schema.
--
-- Validation: exported from the project's Java seeder; 200 unique plot keys,
-- 120 distinct burial plots, existing-plot references and chronological dates
-- checked. Actual Derby execution was unavailable in the build environment.

-- STEP 1: Add only missing plots, retaining existing section values.
INSERT INTO APP.PLOTS (plot_number, section)
SELECT v.plot_number, TRIM(v.section)
FROM (VALUES
    ('A-001', 'Section A'),
    ('A-002', 'Section A'),
    ('A-003', 'Section A'),
    ('A-004', 'Section A'),
    ('A-005', 'Section A'),
    ('A-006', 'Section A'),
    ('A-007', 'Section A'),
    ('A-008', 'Section A'),
    ('A-009', 'Section A'),
    ('A-010', 'Section A'),
    ('A-011', 'Section A'),
    ('A-012', 'Section A'),
    ('A-013', 'Section A'),
    ('A-014', 'Section A'),
    ('A-015', 'Section A'),
    ('A-016', 'Section A'),
    ('A-017', 'Section A'),
    ('A-018', 'Section A'),
    ('A-019', 'Section A'),
    ('A-020', 'Section A'),
    ('A-021', 'Section A'),
    ('A-022', 'Section A'),
    ('A-023', 'Section A'),
    ('A-024', 'Section A'),
    ('A-025', 'Section A'),
    ('A-026', 'Section A'),
    ('A-027', 'Section A'),
    ('A-028', 'Section A'),
    ('A-029', 'Section A'),
    ('A-030', 'Section A'),
    ('A-031', 'Section A'),
    ('A-032', 'Section A'),
    ('A-033', 'Section A'),
    ('A-034', 'Section A'),
    ('A-035', 'Section A'),
    ('A-036', 'Section A'),
    ('A-037', 'Section A'),
    ('A-038', 'Section A'),
    ('A-039', 'Section A'),
    ('A-040', 'Section A'),
    ('A-041', 'Section A'),
    ('A-042', 'Section A'),
    ('A-043', 'Section A'),
    ('A-044', 'Section A'),
    ('A-045', 'Section A'),
    ('A-046', 'Section A'),
    ('A-047', 'Section A'),
    ('A-048', 'Section A'),
    ('A-049', 'Section A'),
    ('A-050', 'Section A'),
    ('B-001', 'Section B'),
    ('B-002', 'Section B'),
    ('B-003', 'Section B'),
    ('B-004', 'Section B'),
    ('B-005', 'Section B'),
    ('B-006', 'Section B'),
    ('B-007', 'Section B'),
    ('B-008', 'Section B'),
    ('B-009', 'Section B'),
    ('B-010', 'Section B'),
    ('B-011', 'Section B'),
    ('B-012', 'Section B'),
    ('B-013', 'Section B'),
    ('B-014', 'Section B'),
    ('B-015', 'Section B'),
    ('B-016', 'Section B'),
    ('B-017', 'Section B'),
    ('B-018', 'Section B'),
    ('B-019', 'Section B'),
    ('B-020', 'Section B'),
    ('B-021', 'Section B'),
    ('B-022', 'Section B'),
    ('B-023', 'Section B'),
    ('B-024', 'Section B'),
    ('B-025', 'Section B'),
    ('B-026', 'Section B'),
    ('B-027', 'Section B'),
    ('B-028', 'Section B'),
    ('B-029', 'Section B'),
    ('B-030', 'Section B'),
    ('B-031', 'Section B'),
    ('B-032', 'Section B'),
    ('B-033', 'Section B'),
    ('B-034', 'Section B'),
    ('B-035', 'Section B'),
    ('B-036', 'Section B'),
    ('B-037', 'Section B'),
    ('B-038', 'Section B'),
    ('B-039', 'Section B'),
    ('B-040', 'Section B'),
    ('B-041', 'Section B'),
    ('B-042', 'Section B'),
    ('B-043', 'Section B'),
    ('B-044', 'Section B'),
    ('B-045', 'Section B'),
    ('B-046', 'Section B'),
    ('B-047', 'Section B'),
    ('B-048', 'Section B'),
    ('B-049', 'Section B'),
    ('B-050', 'Section B'),
    ('C-001', 'Section C'),
    ('C-002', 'Section C'),
    ('C-003', 'Section C'),
    ('C-004', 'Section C'),
    ('C-005', 'Section C'),
    ('C-006', 'Section C'),
    ('C-007', 'Section C'),
    ('C-008', 'Section C'),
    ('C-009', 'Section C'),
    ('C-010', 'Section C'),
    ('C-011', 'Section C'),
    ('C-012', 'Section C'),
    ('C-013', 'Section C'),
    ('C-014', 'Section C'),
    ('C-015', 'Section C'),
    ('C-016', 'Section C'),
    ('C-017', 'Section C'),
    ('C-018', 'Section C'),
    ('C-019', 'Section C'),
    ('C-020', 'Section C'),
    ('C-021', 'Section C'),
    ('C-022', 'Section C'),
    ('C-023', 'Section C'),
    ('C-024', 'Section C'),
    ('C-025', 'Section C'),
    ('C-026', 'Section C'),
    ('C-027', 'Section C'),
    ('C-028', 'Section C'),
    ('C-029', 'Section C'),
    ('C-030', 'Section C'),
    ('C-031', 'Section C'),
    ('C-032', 'Section C'),
    ('C-033', 'Section C'),
    ('C-034', 'Section C'),
    ('C-035', 'Section C'),
    ('C-036', 'Section C'),
    ('C-037', 'Section C'),
    ('C-038', 'Section C'),
    ('C-039', 'Section C'),
    ('C-040', 'Section C'),
    ('C-041', 'Section C'),
    ('C-042', 'Section C'),
    ('C-043', 'Section C'),
    ('C-044', 'Section C'),
    ('C-045', 'Section C'),
    ('C-046', 'Section C'),
    ('C-047', 'Section C'),
    ('C-048', 'Section C'),
    ('C-049', 'Section C'),
    ('C-050', 'Section C'),
    ('D-001', 'Section D'),
    ('D-002', 'Section D'),
    ('D-003', 'Section D'),
    ('D-004', 'Section D'),
    ('D-005', 'Section D'),
    ('D-006', 'Section D'),
    ('D-007', 'Section D'),
    ('D-008', 'Section D'),
    ('D-009', 'Section D'),
    ('D-010', 'Section D'),
    ('D-011', 'Section D'),
    ('D-012', 'Section D'),
    ('D-013', 'Section D'),
    ('D-014', 'Section D'),
    ('D-015', 'Section D'),
    ('D-016', 'Section D'),
    ('D-017', 'Section D'),
    ('D-018', 'Section D'),
    ('D-019', 'Section D'),
    ('D-020', 'Section D'),
    ('D-021', 'Section D'),
    ('D-022', 'Section D'),
    ('D-023', 'Section D'),
    ('D-024', 'Section D'),
    ('D-025', 'Section D'),
    ('D-026', 'Section D'),
    ('D-027', 'Section D'),
    ('D-028', 'Section D'),
    ('D-029', 'Section D'),
    ('D-030', 'Section D'),
    ('D-031', 'Section D'),
    ('D-032', 'Section D'),
    ('D-033', 'Section D'),
    ('D-034', 'Section D'),
    ('D-035', 'Section D'),
    ('D-036', 'Section D'),
    ('D-037', 'Section D'),
    ('D-038', 'Section D'),
    ('D-039', 'Section D'),
    ('D-040', 'Section D'),
    ('D-041', 'Section D'),
    ('D-042', 'Section D'),
    ('D-043', 'Section D'),
    ('D-044', 'Section D'),
    ('D-045', 'Section D'),
    ('D-046', 'Section D'),
    ('D-047', 'Section D'),
    ('D-048', 'Section D'),
    ('D-049', 'Section D'),
    ('D-050', 'Section D')
) AS v (plot_number, section)
WHERE NOT EXISTS (
    SELECT 1 FROM APP.PLOTS existing_plot
    WHERE existing_plot.plot_number = v.plot_number
);

-- STEP 2: Add fictional people only to unoccupied plots.
-- DEATH_DATE is the day of death; BURIAL_DATE is a separate, later date.
INSERT INTO APP.BURIALS
    (deceased_name, birth_date, death_date, burial_date, plot_number)
SELECT TRIM(v.deceased_name), v.birth_date, v.death_date, v.burial_date,
       v.plot_number
FROM (VALUES
    ('Arturo Santos', DATE('1942-10-07'), DATE('2011-09-01'), DATE('2011-09-04'), 'B-046'),
    ('Beatriz Santos', DATE('1939-06-27'), DATE('2018-12-21'), DATE('2018-12-24'), 'C-028'),
    ('Carlos Santos', DATE('1967-11-06'), DATE('2018-08-09'), DATE('2018-08-12'), 'D-032'),
    ('Diana Santos', DATE('1969-12-05'), DATE('2023-10-20'), DATE('2023-10-23'), 'D-040'),
    ('Eduardo Santos', DATE('1954-05-19'), DATE('2023-12-14'), DATE('2023-12-17'), 'C-034'),
    ('Felisa Santos', DATE('1933-08-08'), DATE('2018-06-05'), DATE('2018-06-08'), 'A-008'),
    ('Gabriel Santos', DATE('1956-01-01'), DATE('2014-12-21'), DATE('2014-12-24'), 'C-049'),
    ('Helena Santos', DATE('1955-05-21'), DATE('2015-11-23'), DATE('2015-11-26'), 'C-042'),
    ('Isabel Santos', DATE('1960-09-19'), DATE('2021-06-15'), DATE('2021-06-18'), 'C-030'),
    ('Joaquin Santos', DATE('1950-09-28'), DATE('2018-06-01'), DATE('2018-06-04'), 'D-017'),
    ('Lourdes Santos', DATE('1930-10-12'), DATE('2013-12-18'), DATE('2013-12-21'), 'B-018'),
    ('Manuel Santos', DATE('1966-11-01'), DATE('2011-09-09'), DATE('2011-09-12'), 'C-033'),
    ('Nora Santos', DATE('1931-01-23'), DATE('2018-01-28'), DATE('2018-01-31'), 'A-033'),
    ('Oscar Santos', DATE('1932-02-25'), DATE('2012-02-02'), DATE('2012-02-05'), 'D-023'),
    ('Pilar Santos', DATE('1966-02-11'), DATE('2017-10-06'), DATE('2017-10-09'), 'A-020'),
   
) AS v (deceased_name, birth_date, death_date, burial_date, plot_number)
WHERE EXISTS (
    SELECT 1 FROM APP.PLOTS existing_plot
    WHERE existing_plot.plot_number = v.plot_number
)
AND NOT EXISTS (
    SELECT 1 FROM APP.BURIALS existing_burial
    WHERE existing_burial.plot_number = v.plot_number
);

-- STEP 3: Display the three fields requested for the project.
SELECT deceased_name AS "Name",
       birth_date AS "Birth date",
       death_date AS "Day of death"
FROM APP.BURIALS
ORDER BY deceased_name;

-- Full record information (ID is generated automatically).
SELECT record_id, deceased_name, birth_date, death_date, burial_date, plot_number
FROM APP.BURIALS
ORDER BY record_id;

-- Expected on an initially empty database: 200 / 120 / 80.
SELECT COUNT(*) AS total_plots FROM APP.PLOTS;
SELECT COUNT(*) AS occupied_plots FROM APP.BURIALS;
SELECT COUNT(*) AS available_plots
FROM APP.PLOTS p
WHERE NOT EXISTS (
    SELECT 1 FROM APP.BURIALS b WHERE b.plot_number = p.plot_number
);
